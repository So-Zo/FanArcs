// Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-app.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyBfJvpwph42YmcutCnRpjfhCje-wUWhSng",
    authDomain: "fanarcs-71386.firebaseapp.com",
    projectId: "fanarcs-71386",
    storageBucket: "fanarcs-71386.firebasestorage.app",
    messagingSenderId: "838423282702",
    appId: "1:838423282702:web:e286c52d81092834b4e85f"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);